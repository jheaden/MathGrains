# MathGrains
Calculator app that uses Orleans grains to do the arithmetic.
